import { Component, OnInit } from '@angular/core';
import { AuthService } from './services/auth.service';
import { Subscription } from 'rxjs';

import { HttpClient, HttpResponse, HttpHeaders } from "@angular/common/http";
import { Router } from '@angular/router';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json','X-OBSERVATORY-AUTH': localStorage.getItem("token") })
};


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
}) 

export class AppComponent implements OnInit{
  title = 'Caffeine Overflow';
  isAdmin:boolean;
  private authListenerSubs: Subscription;
  userIsAuthedicated: boolean;
  public token:String;

  constructor(private authService:AuthService,private http: HttpClient, private router:Router){}
  logout(){
    this.authService.logout();
    console.log("done");
   
  }

   ngOnInit(){
    this.authListenerSubs = this.authService
    .getAuthStatusListener()
    .subscribe(async isAdmin => {
         await this.authService.getUserAdmin();
         this.isAdmin=this.authService.getUserAdmin();
     
     
    });  
    
    this.userIsAuthedicated = this.authService.getIsAuth();
      this.authListenerSubs = this.authService.
      getAuthStatusListener().subscribe(isAuthedicated =>{
        this.userIsAuthedicated = isAuthedicated;
      });

     
   }

}
