import { Component, OnInit,Input} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { ShopService }  from '../services/shop.service';
import {MapsComponent} from '../maps/maps.component'; //Maps
import { AuthService } from '../services/auth.service';
import { Shop } from '../models/shop';

@Component({
  providers:[MapsComponent ], //Maps
  selector: 'app-shop-detail',
  templateUrl: './shop-detail.component.html',
  styleUrls: ['./shop-detail.component.css']
})
export class ShopDetailComponent implements OnInit {
  @Input() shop: Shop;
  userIsAuthedicated: boolean;
  authListenerSubs: any;

  ngOnInit(): void {
    this.maps.ngOnInit();
    this.getShop();
    this.userIsAuthedicated = this.authService.getIsAuth();
    this.authListenerSubs = this.authService.
    getAuthStatusListener().subscribe(isAuthedicated =>{
      this.userIsAuthedicated = isAuthedicated;
    });
    

  }


  getShop(): void {
    var id  = this.route.snapshot.paramMap.get('id');
    //var panos = id.toString();
    this.shopService.getShop(id)
      .subscribe(shop => {
        this.shop = shop;
        this.maps.showpoint(this.shop.lat,this.shop.lng,this.shop.name,this.shop.address)});
  }

  goBack(): void {
    this.location.back();
  }

  save(): void {
    this.shopService.updateShop(this.shop)
      .subscribe(() => this.goBack());
  }

  delete(shop: Shop): void {
    this.shopService.deleteShop(shop)
    .subscribe(() => this.goBack());
  }

  constructor(
    private route: ActivatedRoute,
    private shopService: ShopService,
    private location: Location,
    private maps: MapsComponent,
    private authService: AuthService
  ) {}


}
