import { Injectable } from '@angular/core';;
import { Observable, of } from 'rxjs';
import { MessageService } from './message.service';
import { HttpClient, HttpHeaders, HttpParams} from '@angular/common/http';
import { catchError, map, tap } from 'rxjs/operators';
import { Price } from '../models/price';
import { PriceRet } from '../models/PriceRet';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json','X-OBSERVATORY-AUTH': localStorage.getItem("token") })
};

const  params = new  HttpParams().set('start', "1").set('count', "50").set('status', 'active').set('sort', 'name');
console.log(params.toString());



@Injectable({
  providedIn: 'root'
})

export class PriceService {

  private pricesUrl = 'https://localhost:8765/observatory/api/prices';

  
  //'api/shops';  //'http://localhost:3200/api/shops';
  
  //'api/shops';  // URL to web api

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
   
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
   
      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);
   
      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }


  constructor(
    private http: HttpClient,
    private messageService: MessageService) { }

    
  getPrices (): Observable<Price[]> {
      return this.http.get<Price[]>(this.pricesUrl + '?' +params,httpOptions) 
      .pipe(
        tap(_ => this.log('fetched prices')),
        catchError(this.handleError('getPrices', []))
      );
  }


searchPrices(term: string): Observable<PriceRet> {
  if (!term.trim()) {
    // if not search term, return empty hero array.
    return of();
  }
  console.log("serachPrices", term);
  return this.http.get<PriceRet>(`${this.pricesUrl}?${term}`).pipe(
    tap(_ => this.log(`found shops matching "${term}"`)),
    catchError(this.handleError<PriceRet>('searchPrices', ))
  );
}

    /** GET hero by id. Will 404 if id not found */
/** GET hero by id. Will 404 if id not found */
getPrice(id: string): Observable<Price> {
  const url = `${this.pricesUrl}/${id}`;
  return this.http.get<Price>(url).pipe(
    tap(_ => this.log(`fetched price id=${id}`)),
    catchError(this.handleError<Price>(`getPrice id=${id}`))
  );
}
updatePrice (price: Price): Observable<any> {
  return this.http.put(this.pricesUrl, price, httpOptions).pipe(
    tap(_ => this.log(`updated price id=${price.id}`)),
    catchError(this.handleError<any>('updatePrice'))
  );
}

updatePrice2(price: Price): Observable<any> {
  return this.http.patch(this.pricesUrl, price, httpOptions).pipe(
    tap(_ => this.log(`updated price id=${price.id}`)),
    catchError(this.handleError<any>('updatePrice'))
  );
}

/** POST: add a new hero to the server */
addPrice (price: Price): Observable<Price> {
  return this.http.post<Price>(this.pricesUrl, price, httpOptions).pipe(
    tap((newPrice: Price) => this.log(`added price w/ id=${newPrice.id}`)),
    catchError(this.handleError<Price>('addPrice'))
  );
}

/** DELETE: delete the hero from the server */
deletePrice (price: Price | number): Observable<Price> {
  const id = typeof price === 'number' ? price : price.id;
  const url = `${this.pricesUrl}/${id}`;

  return this.http.delete<Price>(url, httpOptions).pipe(
    tap(_ => this.log(`deleted price id=${id}`)),
    catchError(this.handleError<Price>('deletePrice'))
  );
}

/* GET heroes whose name contains search term */


create(price:Price):Observable<Price>{
  return this.http.post<Price>(this.pricesUrl,price,httpOptions).
 pipe(
   tap((newPrice: Price) => this.log(`added price w/ id=${newPrice.id}`)),
    catchError(this.handleError<Price>('create'))); 

}

    /** Log a HeroService message with the MessageService */
    private log(message: string) {
        this.messageService.add(`PriceService: ${message}`);
    }
}


