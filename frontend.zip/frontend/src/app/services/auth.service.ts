import { Injectable } from "@angular/core";
import { HttpClient, HttpResponse } from "@angular/common/http";
import { Router } from "@angular/router";
import { Subject } from "rxjs";
import { User } from '../models/user';

var headers = new Headers();


@Injectable({ providedIn: "root" })
export class AuthService {
  private isAuthenticated = false;
  private token: string;
  private userId: string;
  private userAdmin:boolean;
  private isAdmin: boolean;
  private username:string;
  private authStatusListener = new Subject<boolean>();
  

  constructor(private http: HttpClient, private router: Router) {}

  getToken() {
    this.token = localStorage.getItem("token");
    return this.token;
  }

  getIsAuth() {
    return  this.isAuthenticated;
  }

  getUserId() {
    return this.userId;
  }

  getUserName() {
    
    return this.username;
  }

  getUserAdmin(){
    return this.userAdmin;
  }

  getAuthStatusListener() {
    return this.authStatusListener.asObservable();
  }

 createUser(email: string,username: string, password: string) {
    var user: User = {email: email, username: username, password: password };
    this.http
      .post<any>("https://localhost:8765/observatory/api/users", user, {observe:'response'})
      .subscribe(res => {
        const token = res.headers.get('X-OBSERVATORY-AUTH');
        console.log(token);
        this.token = token;
        if (token!=null) {
          this.isAuthenticated = true;
          this.userId = res.body.id;
          this.isAdmin=res.body.isAdmin;
          this.username=res.body.username;
          this.userAdmin=res.body.isAdmin;
          this.userAdmin=this.isAdmin;
          this.authStatusListener.next(true);
          this.saveAuthData(token, this.userId,this.username, this.isAdmin);          
        }
      });
  }

  login( username: string,  password: string) {
    var user: User = {  username: username, password: password };
    this.http
      .post<any>("https://localhost:8765/observatory/api/login",user, {observe:'response'})
      .subscribe((res) => {
        const token = res.headers.get('X-OBSERVATORY-AUTH');
        console.log(token);
        this.token = token;
        if (token!==null) {
          this.isAuthenticated = true;
          this.userId = res.body.id;
          this.isAdmin=res.body.isAdmin;
          this.userAdmin=res.body.isAdmin;
          this.username=res.body.username;
          this.authStatusListener.next(true);
          this.saveAuthData(token, this.userId,this.username, this.isAdmin); 
        }
      });

  }

  autoAuthUser() {
    const authInformation = this.getAuthData();
    if (!authInformation) {
      return;
    }
  }

  logout() {
    this.token = null;
    this.isAuthenticated = false;
    this.authStatusListener.next(false);
    this.userId = null;
    this.userAdmin=false;
    this.isAdmin=false;
    this.username=null;
    this.clearAuthData();
  //  this.http.post("http://localhost:8765/observatory/api/logout");
    this.router.navigate(["/home"]);
  }


  private saveAuthData(token: string, userId: string, username:string, isAdmin:boolean) {
    localStorage.setItem("token", token);
    localStorage.setItem("userId", userId);
    localStorage.setItem("username", username);
    localStorage.setItem("isAdmin", JSON.stringify(isAdmin));
  }

  private clearAuthData() {
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
    localStorage.removeItem("username");
    localStorage.removeItem("isAdmin");
  }

  private getAuthData() {
    const token = localStorage.getItem("token");
    const userId = localStorage.getItem("userId");
    const username = localStorage.getItem("username");
    const isAdmin = localStorage.getItem("isAdmin");
    
    if (!token ) {
      return;
    }
    return {
      token: token,
      userId: userId,
      isAdmin: isAdmin,
      username: username
    }
  }
} 