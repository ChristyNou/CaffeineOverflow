import { Component, OnInit} from '@angular/core';
import { FormBuilder} from '@angular/forms';
import { Validators } from '@angular/forms';
import { PriceService } from '../services/price.service';
import { ShopService } from '../services/shop.service';
import { ProductService } from '../services/product.service';
import { Shop } from '../models/shop';
import { Product } from '../models/product';
import { Price } from '../models/price';


@Component({
  selector: 'app-price-editor',
  templateUrl: './price-editor.component.html',
  styleUrls: ['./price-editor.component.css']
})
export class PriceEditorComponent implements OnInit{

  priceForm = this.fb.group({
    price: ['',  Validators.required],
    dateFrom: ['',  Validators.required],
    dateTo: ['',  Validators.required],
    productId: ['',Validators.required],
    shopId: ['',Validators.required]  
  });

  shops : Shop[];
 products: Product[];

  myprice : Price;
  get f(){
    return this.priceForm.controls ;
  }
  onSubmit() {
    console.log("]");
    // TODO: Use EventEmitter with form value
     
   /*if (this.priceForm.invalid)
   {
     return;
   }
    */
    this.myprice = {price: this.f.price.value, 
                    dateFrom : this.f.dateFrom.value,
                    dateTo: this.f.dateTo.value, 
                    productId:this.f.productId.value,
                    shopId: this.f.shopId.value
                  
                   };
      
                   console.log(this.priceForm.value);      

    this.priceService.create(this.myprice)
   .subscribe(
     //Response => {Response.
     resp => {console.log(this.priceForm.value);
    error=> console.log(error)}
    );
    
  }
  ngOnInit(){
    this.shopService.getShops(100, 0,'ALL','name|ASC','').subscribe(shops => this.shops = shops.shops);
    this.productService.getProducts(20,0,'ALL','name|ASC','').subscribe(products => this.products = products.products);
  }
  constructor(private fb: FormBuilder,
    private priceService: PriceService,
    private shopService:ShopService,
    private productService: ProductService ) { 
    
    this.shopService.getShops(100, 0,'ALL','name|ASC','').subscribe(shops => this.shops = shops.shops);
     this.productService.getProducts(20,0,'ALL','name|ASC','').subscribe(products => this.products = products.products);
      
    }
}