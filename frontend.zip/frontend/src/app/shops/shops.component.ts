import { Component, OnInit,OnDestroy } from '@angular/core';
import { ShopService } from '../services/shop.service';
import { PageEvent } from "@angular/material";
import { Subscription } from "rxjs";
import {MapsComponent} from '../maps/maps.component'; //Maps
import { FormBuilder } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { Shop } from '../models/shop';

@Component({
  providers:[MapsComponent ], //Maps
  selector: 'app-shops',
  templateUrl: './shops.component.html',
  styleUrls: ['./shops.component.css']
})
export class ShopsComponent implements OnInit {

  public shops: Shop[];
  private statuses:{id:string,name:string} [];
  private sorts: {id:number|string,name:string } [];
  userIsAuthedicated: boolean;
  authListenerSubs: any;

  totalPosts = 30;
  count = 100;
  start = 0;

  //currentPage = 1;
  pageSizeOptions = [1,2,3,4,5,6];

  status = 'ALL';
  sort = 'name|ASC';
  search = "";
  private columns:string[];
  filterForm = this.fb.group({
    statusId:[''],
    sortId:[''],
    start:[''],
    count:[''],
    find: [''],
    
  }); 


  constructor(private shopService: ShopService, private fb: FormBuilder ,private authService:AuthService, private maps: MapsComponent) { } // Maps

  onSubmit(): void {
    console.log(this.filterForm.controls['count'].value);
     this.shopService.getShops(this.filterForm.controls['count'].value,this.filterForm.controls['start'].value,this.filterForm.controls['statusId'].value,
    this.filterForm.controls['sortId'].value,this.filterForm.controls['find'].value)
         .subscribe(shops => this.shops = shops.shops);
   }
 

  delete(shop: Shop): void {
    this.shops = this.shops.filter(h => h !== shop);
    this.shopService.deleteShop(shop).subscribe();
  }

  onChangedPage(pageData:PageEvent){
    //console.log(pageData);
    this.start = pageData.pageIndex +1;//this.start + 1; //pageData.pageIndex +1;
    this.count = pageData.pageSize  //this.count ; //pageData.pageSize;
    this.shopService.getShops(this.count,this.start,this.status,this.sort,this.search);

  }
  

  ngOnInit() {
    this.shopService.getShops(20, 0,'ALL','name|ASC','').subscribe(shops => this.shops = shops.shops);
    this.statuses= [{id:"ALL",name:"Όλα"}, {id:"ACTIVE",name:"Ενεργά "},{id:"WITHDRAWN",name:" Μη ενεργά"}];
    this.sorts = [
      {id:'name|ASC',name:'Αύξουσα ως προς όνομα'},
      {id:'name|DESC',name:'Φθίνουσα ως προς όνομα'},
      {id:'id|ASC',name:'Αύξουσα ως προς κωδικό'},
      {id:'id|DESC',name:'Φθίνουσα ως προς κωδικό'}];
    this.columns= [" Όνομα Καταστήματος","Κωδικός Καταστήματος"];  
    this.maps.ngOnInit(); // Maps
    this.userIsAuthedicated = this.authService.getIsAuth();
    this.authListenerSubs = this.authService.
    getAuthStatusListener().subscribe(isAuthedicated =>{
      this.userIsAuthedicated = isAuthedicated;
    });
  }



}
