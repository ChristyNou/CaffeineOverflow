import { Component, OnInit } from '@angular/core';
import { PriceService } from '../services/price.service';
import {MapsComponent} from '../maps/maps.component'; //Maps
import { HereService } from "../services/here.service"; // Maps
import { FormBuilder} from '@angular/forms';
import { ShopService } from '../services/shop.service';
import { ProductService } from '../services/product.service';
import {FormControl} from '@angular/forms';  
import { CloseScrollStrategy } from '@angular/cdk/overlay';
import { Price } from '../models/price';
import { Shop } from '../models/shop';
import { Product } from '../models/product';




@Component({
  providers:[MapsComponent ], //Maps
  selector: 'app-prices', 
  templateUrl: './prices.component.html',
  styleUrls: ['./prices.component.css'],

})




export class PricesComponent implements OnInit {

  prices : Price[];
  shops : Shop[];
  products : Product[];

  constructor(private priceService: PriceService, 
              private maps: MapsComponent, 
              private fb: FormBuilder, 
              private shopService:ShopService, 
              private productService:ProductService, 
              private here: HereService) { } // Maps
  
  searchForm = this.fb.group({
    location: [''],
    distance: [''],
    fromdate: [''],
    todate: [''],
    // listshops: [''],     DELETED
    // listproducts: [''] ,   DELETED
    sort: [''],
    tax:['']
  });

  getPrices(): void {
    this.priceService.getPrices()
        .subscribe(prices => this.prices = prices);
  }

  // ADDED
  getShops(){  this.shopService.getShops(20,0,'ALL','name|ASC','').subscribe(response=>
    {
        this.shops=response.shops;
        console.log(response);
        for(let i = 0 ; i < this.shops.length; i++){
          var shop = this.shops[i].id + " - " + this.shops[i].name;
  
          this.toppingList.push(shop);
  
        }
        
      });
    }

    // ADDED
  getProducts(){  this.productService.getProducts(20,0,'ALL','name|ASC','').subscribe(response=>
      {
          this.products=response.products;
          console.log(response);
          for(let i = 0 ; i < this.products.length; i++){
            var product = this.products[i].id + " - " + this.products[i].name;
    
            this.betaList.push(product);
    
          }
          
        });
      }


    //ADDED
  toppings = new FormControl();
  toppingList: string[] =  ['Select All'];
  betas = new FormControl();
  betaList: string[] =  ['Select All'];



  ngOnInit() {
    this.maps.ngOnInit(); 

    this.getShops();

    this.getProducts();
    

  }



  onFind() {
    //console.log("On Find ------");
    let findadd = (this.searchForm.get('location').value);
    this.maps.onFindWithAddress(findadd).then(result=>{
            console.log("A3 =", result);
    });
  }

  
  onSubmit() {
    // console.log ("On Submit");
  
    let criteria = "sort=price|ASC";
    let sort = this.searchForm.get('sort').value;
    let tax = this.searchForm.get('tax').value;
    if (sort == "") sort = "price";
    if (tax == "") tax = "ASC";
    criteria = "sort=" + sort + "|" + tax;
    console.log("Criteria 1: ", criteria);
    if (((this.searchForm.get('fromdate').value != "") && (this.searchForm.get('todate').value == ""))||((this.searchForm.get('fromdate').value == "") && (this.searchForm.get('todate').value != ""))){
      //popopopopopopopop UP
      console.log("Missing Date information");
      return -1;
    }
    if (this.searchForm.get('fromdate').value != "")  {
      criteria = criteria + "&dateFrom=" + this.searchForm.get('fromdate').value + "&dateTo=" + this.searchForm.get('todate').value;
    }

    console.log("Criteria 2: ", criteria);

    // ADDED
    if (this.toppings.value.length != 0) {
      for(let i = 0 ; i < this.toppings.value.length; i++){

        criteria = criteria + "&shops=" + this.toppings.value[i].substr(0,24);
      }
      console.log("Criteria 3: ", criteria);
    }

    // ADDED
        if (this.betas.value.length != 0) {
          for(let i = 0 ; i < this.betas.value.length; i++){
    
            criteria = criteria + "&products=" + this.betas.value[i].substr(0,24);
          }
          console.log("Criteria 4: ", criteria);
      }
    

    if (((this.searchForm.get('location').value != "") && (this.searchForm.get('distance').value == ""))||((this.searchForm.get('location').value == "") && (this.searchForm.get('distance').value != ""))){
      //popopopopopopopop UP
      console.log("Missing Location information");
      return -1;
    }
    if (this.searchForm.get('location').value != "")  {

      let findadd = (this.searchForm.get('location').value);
      this.maps.onFindWithAddress(findadd).then(result=>{
        console.log("Result X ",result[0]);

        criteria =  criteria + "&geoDist="+this.searchForm.get('distance').value+"&geoLng="+result[0]+"&geoLat="+result[1];
        console.log("Criteria Final: ", criteria);

        this.priceService.searchPrices(criteria)
        .subscribe(prices => {
          this.prices = prices.prices
          console.log(this.prices)});

        }, error => {
        console.error(error);
      });
    } else {
      this.priceService.searchPrices(criteria)
        .subscribe(prices => {
          this.prices = prices.prices
          console.log(this.prices)});

        
    }

  }
 
}


