import { Price } from './price';

export class PriceRet {
    start : number;
    count : number;
    total: number;
    prices : Price[];
    
  }