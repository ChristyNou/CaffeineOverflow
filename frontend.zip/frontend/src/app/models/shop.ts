export class Shop {
    id?: String;
    name: string;
    address: string;
    lng: number;
    lat: number;
    tags: string[];
    withdrawn?: boolean;
  }