import { Shop } from './shop';

export class ShopRet {
    start : number;
    count : number;
    total: number;
    shops: Shop[];
    
  }