export class Price {
    id?: String;
    price: DoubleRange;
    dateFrom:Date;
    dateTo:Date;
    productId: String;
    shopId:String;

  }