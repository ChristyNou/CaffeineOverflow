import { Product } from './product';

export class ProductRet {
    start : number;
    count : number;
    total: number;
    products: Product[];
    
  }