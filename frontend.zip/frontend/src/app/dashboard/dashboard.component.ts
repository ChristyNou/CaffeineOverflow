import { Component, OnInit } from '@angular/core';
import { ShopService } from '../services/shop.service';
import { ProductService } from '../services/product.service';
import { Shop } from '../models/shop';
import { Product } from '../models/product';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: [ './dashboard.component.css' ]
})
export class DashboardComponent implements OnInit {
  shops: Shop[] = [];
  products: Product[] = [];

  constructor(private shopService: ShopService,
              private productService: ProductService) { }

  ngOnInit() {
    this.getShops();
    this.getProducts();
  }

  getShops(): void {
    this.shopService.getShops(20,0,'ALL','name|ASC','')
      .subscribe(shops => this.shops = shops.shops.slice(0, 4));
  }

  getProducts(): void {
    this.productService.getProducts(20,0,'ALL','name|ASC','')
      .subscribe(products => this.products = products.products.slice(0, 4));
  }

  
}