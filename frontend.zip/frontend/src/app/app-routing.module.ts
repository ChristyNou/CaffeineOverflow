import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ShopsComponent }  from './shops/shops.component';
import { DashboardComponent }   from './dashboard/dashboard.component';
import { ShopDetailComponent }  from './shop-detail/shop-detail.component';

import {ShopEditorComponent} from './shop-editor/shop-editor.component';
import { ProductEditorComponent } from './product-editor/product-editor.component';
import { ProductsComponent } from './products/products.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { UsersComponent } from './users/users.component';
import { UserDetailComponent } from './user-detail/user-detail.component';
import { PricesComponent } from './prices/prices.component';
import { PriceEditorComponent } from './price-editor/price-editor.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { NotfoundComponent } from './notfound/notfound.component';

const routes: Routes = [
  { path: 'shops/:id', component: ShopDetailComponent },
  { path: 'products/:id', component: ProductDetailComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'shops', component: ShopsComponent },
  { path: 'addshop', component: ShopEditorComponent},
  { path: 'products', component: ProductsComponent },
  { path: 'addproduct', component: ProductEditorComponent},
  { path: 'users', component: UsersComponent},
  { path: 'users/:id', component: UserDetailComponent},
  { path: 'prices', component: PricesComponent},
  {path: 'addprice', component: PriceEditorComponent},
  { path: 'login', component: LoginComponent},
  { path: 'register', component: RegisterComponent },
  {path: 'home', component: HomeComponent},
  {path:'**', component:NotfoundComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
