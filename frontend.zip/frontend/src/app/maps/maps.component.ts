import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as ol from 'openlayers';
import { HereService } from "../services/here.service";
import { ShopRet } from '../models/ShopRet';


const API_END_POINT = 'https://localhost:8765/observatory/api/shops?start=0&count=100&sort=name|ASC&status=ALL&search=';

@Component({
  selector: 'app-maps',
  templateUrl: './maps.component.html',
  styleUrls: ['./maps.component.css']
})


export class MapsComponent implements OnInit {

  public query: string;
  public position: string;
  public locations: Array<any>;

  public constructor(private here: HereService, private httmp: HttpClient) {
      //this.query = "Πεντέλη, Ελλάδα";
      //this.position = "37.7397,-121.4252";
  }
    

  public getAddress():any {
    if(this.query != "") {
      this.vectorSource.clear();
      this.getMyPois();

        this.here.getAddress(this.query).then(result => {
            this.locations = <Array<any>>result;
            //console.log(this.locations);

            this.locations.forEach(datum => {
              //console.log("DDDD", datum)
              let lat = parseFloat(datum.Location.DisplayPosition.Latitude);
              let lon = parseFloat(datum.Location.DisplayPosition.Longitude);
              let lonlat: [number, number] = [lon, lat];
              let coordinates = ol.proj.fromLonLat(lonlat);
              let feature = new ol.Feature(
                new ol.geom.Point(coordinates)
              );
              let address = datum.Location.Address.Label;
              //console.log("A1 = ", address);
                            
              let style = new ol.style.Style(
                {
                image: new ol.style.Icon(
                {
    
                 src: 'assets/target1.png'
    
                })
                }
              )
              // let value = parseFloat(datum.value);
              feature.setStyle(style);
              feature.setProperties({name:"result",address:address,latitude:datum.lat,longtitude:datum.lng});
              this.vectorSource.addFeature(feature);
            })

            let lat = parseFloat(this.locations[0].Location.DisplayPosition.Latitude);
            let lon = parseFloat(this.locations[0].Location.DisplayPosition.Longitude);
            // console.log("X1= ", lat);
            // console.log("Y1= ", lon);

           let lonlat: [number, number] = [lon, lat];
           
            this.map.setView(new ol.View({
              projection: 'EPSG:3857',
              center:  ol.proj.fromLonLat(lonlat),
              zoom: 20
            }));

            console.log("A1 = ", lonlat);
            return(lonlat);

        }, error => {
            console.error(error);
            return(error);

        });
    }
  }

public getAddressFromLatLng() {
  if(this.position != "") {
      this.here.getAddressFromLatLng(this.position).then(result => {
          this.locations = <Array<any>>result;
      }, error => {
          console.error(error);
      });
  }
}


  map: ol.Map;
  vectorLayer: ol.layer.Vector;
  vectorSource: ol.source.Vector;


  form_name: string = "";
  form_address: string = "";

  display_name:string='';
  display_address:string='';

  form_left:number;
  form_top:number;




  ngOnInit() {

    //console.log("XXXXXXX");

    this.vectorSource = new ol.source.Vector();
    this.vectorLayer = new ol.layer.Vector({
      source: this.vectorSource
    });

    this.map = new ol.Map({
      target: "map",
      layers: [
        new ol.layer.Tile({ source: new ol.source.OSM() }),
        this.vectorLayer
      ],
      view: new ol.View({
        center: ol.proj.fromLonLat([23, 38]),
        zoom: 8
      })
    });

    // console.log("YYYYYY");
    
    this.map.on('pointermove', (evt: any) => {
        // console.log("On Hover!");
        let found = false;
      
        this.map.forEachFeatureAtPixel(evt.pixel,(feature=>{
          let p = feature.getProperties();
          //console.log("Properties", p.x, p.y);
          
          this.display_name = p.name;
          this.display_address = p.address;
          this.form_left = evt.pixel[0] +10+300;
          this.form_top = evt.pixel[1]+10;
          found = true;
        }))
        if(!found){
          this.form_left = -9999;
        }
    })

    this.getMyPois();

  }
  showpoint(lat:number, lng: number, name:string, address:string){
    this.vectorSource.clear();
    let lonlat: [number, number] = [lat, lng];
          let coordinates = ol.proj.fromLonLat(lonlat);
          let feature = new ol.Feature(
            new ol.geom.Point(coordinates)
          );
          let color= 'red';        
          let style = new ol.style.Style(
            {
            image: new ol.style.Icon(
		        {

             src: 'assets/point2.png'

            })
            }
          )

          feature.setStyle(style);
          feature.setProperties({name:name,address:address,latitude:lat,longtitude:lng});
          this.vectorSource.addFeature(feature);
          this.map.setView(new ol.View({
            projection: 'EPSG:3857',
            center:  ol.proj.fromLonLat(lonlat),
            zoom: 10
          }));

  }
  
  getMyPois() {
     console.log("On Get My Points")
    this.httmp.get(API_END_POINT)
      .toPromise()
     // .then((d: { lat: number, lng: number, name: string, address: string }[]) => {
        .then((td:ShopRet) => {
        console.log("CCCCC gggg",td)
        //let max = Math.max(...d.map(dd=>parseFloat(dd.address)));
       
        td.shops.forEach(datum => {
          //console.log("DDDD", datum)
          let lonlat: [number, number] = [datum.lat, datum.lng];
          let coordinates = ol.proj.fromLonLat(lonlat);
          let feature = new ol.Feature(
            new ol.geom.Point(coordinates)
          );
          let address = parseFloat(datum.address);
          
          
          let color= 'red';

          
          let style = new ol.style.Style(
            {
            image: new ol.style.Icon(
		        {

             src: 'assets/point2.png'

            })
            }
          )
		  
          

          // let value = parseFloat(datum.value);
          feature.setStyle(style);
          feature.setProperties({name:datum.name,address:datum.address,latitude:datum.lat,longtitude:datum.lng});
          this.vectorSource.addFeature(feature);
        })

      });
  }



  onSave() {

      
    let coordinates = this.map.getView().getCenter();
    let lonlat = ol.proj.toLonLat(coordinates);

    //console.log("Coordinates", coordinates);
    //console.log("LonLat ",lonlat )
    let object = {
      latitude: lonlat[0],
      longtitude: lonlat[1],
      name: this.form_name,
      address: ""+this.form_address
    }
    //console.log("Save",this.vectorSource )
    this.vectorSource.clear();

    this.httmp.post(API_END_POINT, object)
      .toPromise().then(d => {
        this.getMyPois();
      })
  }


  refreshMap(){
    // console.log("On refresh Map");
    this.vectorSource.clear();
    this.getMyPois();



  }
  onFind() {
    
    this.query =  this.form_address;
    //console.log("QQQ",this.query);
    this.getAddress();


  }

  onFindWithAddress(address) {
    return new Promise((resolve, reject) => {
      this.query =  address;
      // this.getAddress(); // Original
      
      this.getAddressPromise(address).then(result=> {
        console.log("A2 :", result);
        resolve(result);
      })
    });



  
  }


  public getAddressPromise(addr: string) {
    return new Promise((resolve, reject) => {
      if(addr != "") {
        this.vectorSource.clear();
        this.getMyPois();
  
          this.here.getAddress(addr).then(result => {
              this.locations = <Array<any>>result;
              //console.log(this.locations);
  
              this.locations.forEach(datum => {
                //console.log("DDDD", datum)
                let lat = parseFloat(datum.Location.DisplayPosition.Latitude);
                let lon = parseFloat(datum.Location.DisplayPosition.Longitude);
                let lonlat: [number, number] = [lon, lat];
                let coordinates = ol.proj.fromLonLat(lonlat);
                let feature = new ol.Feature(
                  new ol.geom.Point(coordinates)
                );
                let address = datum.Location.Address.Label;
                //console.log("A1 = ", address);
                              
                let style = new ol.style.Style(
                  {
                  image: new ol.style.Icon(
                  {
      
                   src: 'assets/target1.png'
      
                  })
                  }
                )
                // let value = parseFloat(datum.value);
                feature.setStyle(style);
                feature.setProperties({name:"result",address:address,latitude:datum.lat,longtitude:datum.lng});
                this.vectorSource.addFeature(feature);
              })
  
              let lat = parseFloat(this.locations[0].Location.DisplayPosition.Latitude);
              let lon = parseFloat(this.locations[0].Location.DisplayPosition.Longitude);
              // console.log("X1= ", lat);
              // console.log("Y1= ", lon);
  
             let lonlat: [number, number] = [lon, lat];
             
              this.map.setView(new ol.View({
                projection: 'EPSG:3857',
                center:  ol.proj.fromLonLat(lonlat),
                zoom: 20
              }));
  
              console.log("A1 = ", lonlat);
              resolve(lonlat);
  
          }, error => {
              console.error(error);
              reject(error);
  
          });
      }
    });
      
      
 
  

    }



}