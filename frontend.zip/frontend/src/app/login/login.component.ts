import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { AuthService } from '../services/auth.service';

@Component(
    {selector: 'app-login',
    templateUrl: 'login.component.html'
    })
export class LoginComponent implements OnInit {
    loginForm: FormGroup;
    loading = false;
    submitted :boolean;
    isAdmin:boolean;
    private authListenerSubs: Subscription;

    constructor(
        private formBuilder: FormBuilder,
        private route: ActivatedRoute,
        private router: Router,
        private authService: AuthService) {}

    ngOnInit() {
        
        this.loginForm = this.formBuilder.group({
            username: ['', Validators.required],
            password: ['', Validators.required]
        });

    }

    // convenience getter for easy access to form fields
    get f() { return this.loginForm.controls; }

    onSubmit() {
        this.submitted = true;


        if (this.loginForm.invalid) {
            return;
        } 
        
        this.loading = true;
        
        this.authService.login(this.f.username.value, this.f.password.value);
       
        this.authListenerSubs = this.authService
          .getAuthStatusListener()
          .subscribe(async isAdmin => {
               await this.authService.getUserAdmin();
            console.log(this.authService.getUserAdmin());
            if (!this.authService.getUserAdmin()){
                this.router.navigate(['/dashboard']);
              }
            else{
                this.router.navigate(['/dashboard']);
              }
          });     
        
      
    }


}
