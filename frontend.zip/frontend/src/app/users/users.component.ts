
import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { FormBuilder } from '@angular/forms';
import { User } from '../models/user';


@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  users : User[];
  private statuses:{id:string,name:string} [];
  private sorts: {id:number|string,name:string } [];
  private columns:string[];

  filterForm = this.fb.group({
    statusId:[''],
    sortId:[''],
  }); 

  constructor(private userService: UserService,private fb: FormBuilder ) { }
  onSubmit(): void {
     this.userService.getUsers(this.filterForm.controls['statusId'].value,
    this.filterForm.controls['sortId'].value)
         .subscribe(users => this.users = users);
   }



  ngOnInit() {
    this.userService.getUsers('ALL','name|ASC')
      .subscribe(users => this.users = users);
    this.statuses= [{id:"ALL",name:"Όλα"}, {id:"ACTIVE",name:"Ενεργά "},{id:"WITHDRAWN",name:" Μη ενεργά"}];
    this.sorts = [
        {id:'name|ASC',name:'Αύξουσα ως προς όνομα'},
        {id:'name|DESC',name:'Φθίνουσα ως προς όνομα'},
        {id:'id|ASC',name:'Αύξουσα ως προς κωδικό'},
        {id:'id|DESC',name:'Φθίνουσα ως προς κωδικό'}];
    this.columns= [" Όνομα Χρήστη","Κωδικός Χρήστη"]; 
     
  }

}
