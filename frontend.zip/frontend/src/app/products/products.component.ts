import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product.service';
import { FormBuilder } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { Product } from '../models/product';


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  products : Product[];
  private statuses:{id:string,name:string} [];
  private sorts: {id:number|string,name:string } [];
  private columns:string[];
  userIsAuthedicated: boolean;
  authListenerSubs: any;

  start = 0; 
  filterForm = this.fb.group({
    statusId:[''],
    sortId:[''],
    count:[''],
    start:[''],
    find: ['']
  }); 


  constructor(private productService: ProductService,private fb: FormBuilder,private authService:AuthService ) { }
  
  onSubmit(): void {
    console.log(this.filterForm.controls['count'].value);
     this.productService.getProducts(this.filterForm.controls['count'].value,this.filterForm.controls['start'].value,this.filterForm.controls['statusId'].value,
    this.filterForm.controls['sortId'].value,this.filterForm.controls['find'].value)
         .subscribe(products => this.products = products.products);
   }

  


  delete(product: Product): void {
    this.products = this.products.filter(h => h !== product);
    this.productService.deleteProduct(product).subscribe();
  } 
  

  ngOnInit() {
      this.productService.getProducts(20, 0,'ALL','name|ASC','').subscribe(products => this.products = products.products);
      this.statuses= [{id:"ALL",name:"Όλα"}, {id:"ACTIVE",name:"Ενεργά "},{id:"WITHDRAWN",name:" Μη ενεργά"}];
      this.sorts = [
        {id:'name|ASC',name:'Αύξουσα ως προς όνομα'},
        {id:'name|DESC',name:'Φθίνουσα ως προς όνομα'},
        {id:'id|ASC',name:'Αύξουσα ως προς κωδικό'},
        {id:'id|DESC',name:'Φθίνουσα ως προς κωδικό'}];
      this.columns= [" Όνομα Προϊόντος","Κωδικός Προϊόντος"];  
      this.userIsAuthedicated = this.authService.getIsAuth();
      this.authListenerSubs = this.authService.
      getAuthStatusListener().subscribe(isAuthedicated =>{
        this.userIsAuthedicated = isAuthedicated;
      });
     

    }
}
