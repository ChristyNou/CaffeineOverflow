import { Shop } from './../models/shop';
import { Component} from '@angular/core';
import { OnInit} from '@angular/core';
import { FormBuilder} from '@angular/forms';
import { Validators } from '@angular/forms';
import { FormArray } from '@angular/forms';
import { ShopService } from '../services/shop.service';
import { ShopsComponent } from '../shops/shops.component';
import { Router } from '@angular/router';
import {MapsComponent} from '../maps/maps.component'; //Maps
import { HereService } from "../services/here.service"; // Maps


@Component({
  providers:[MapsComponent ], //Maps
  selector: 'app-shop-editor',
  templateUrl: './shop-editor.component.html',
  styleUrls: ['./shop-editor.component.css']
})
export class ShopEditorComponent implements OnInit{ //Maps

  shopForm = this.fb.group({
    shopname: ['',  Validators.required],
    address: this.fb.group({
      street: ['',  Validators.required],
      city: ['',  Validators.required],
      zip: ['']  

    }),

    tags: this.fb.array([
      this.fb.control('')
    ])
  });
  

  get tags() {
    return this.shopForm.get('tags') as FormArray;
  }

  addtags() {
    this.tags.push(this.fb.control(''));
  } 

  myshop : Shop;
 

  i = 0;
  // Maps - modified
  locations: Array<any>;
  lat = 23;
  lon = 38;
  onSubmit() {
    // console.log ("On Submit");
    let findadd = (this.shopForm.get('address.street').value).concat(",")
          .concat(this.shopForm.get('address.city').value);

    this.here.getAddress(findadd).then(result => {
      
      this.locations = <Array<any>>result;
      this.lat = parseFloat(this.locations[0].Location.DisplayPosition.Latitude);
      this.lon = parseFloat(this.locations[0].Location.DisplayPosition.Longitude);

      // TODO: Use EventEmitter with form value
      //this.xri = this.shopForm.get('shopname').value; 
      this.shopForm.controls['shopname'].value ;
      
      //this.myshop = { id: (this.i++) , name: this.shopForm.get('shopname').value};
  
      this.myshop = {name: this.shopForm.controls['shopname'].value, 
                      address : (this.shopForm.get('address.street').value).concat(",").concat(this.shopForm.get('address.city').value)
                      .concat(",").concat(",").concat(this.shopForm.get('address.zip').value),
                    lat: this.lon , lng: this.lat , tags: this.shopForm.controls['tags'].value };
     // console.log(this.myshop);
      this.shopService.create(this.myshop)
           .subscribe(
             res=> {this.router.navigate(['/shops']); console.log(this.myshop);},
              error => {console.log(this.shopForm.value);}
            );

      }, error => {
      console.error(error);
    });

  }
  onFind() {
    //console.log("On Find ------");
    let findadd = (this.shopForm.get('address.street').value).concat(",")
                  .concat(this.shopForm.get('address.city').value);
    this.maps.onFindWithAddress(findadd).then(result=>{
            console.log("A3 =", result);
    });

  }
  ngOnInit() { 

    this.maps.ngOnInit(); 
  }

  constructor(
    private fb: FormBuilder,
    private shopService: ShopService, 
    private maps: MapsComponent, // Maps
    private here: HereService, 
    private router: Router){} // Maps){}// { }
}