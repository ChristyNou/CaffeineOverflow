import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { AuthService } from '../services/auth.service';




@Component({templateUrl: 'register.component.html'})
export class RegisterComponent implements OnInit {
    registerForm: FormGroup;
    loading = false;
    submitted = false;
    isAdmin:boolean;
    private authListenerSubs: Subscription;

    constructor(
        private formBuilder: FormBuilder,
        private router: Router,
        private authService: AuthService) { }

    ngOnInit() {
       this.registerForm = this.formBuilder.group({
            email:['',Validators.required],
            username: ['', Validators.required],
            password: ['', [Validators.required, Validators.minLength(5)]]
        });
    }

    // convenience getter for easy access to form fields
    get f() { return this.registerForm.controls; }

    onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.registerForm.invalid) {
            return;
        }

        this.authService.createUser(this.f.email.value,this.f.username.value, this.f.password.value);

        this.authListenerSubs = this.authService
          .getAuthStatusListener()
          .subscribe(async isAdmin => {
               await this.authService.getUserAdmin();
            console.log(this.authService.getUserAdmin());
            if (!this.authService.getUserAdmin()){
                this.router.navigate(['/dashboard']);
              }
            else{
                this.router.navigate(['/dashboard']);
              }
          });     
        
        this.loading = true;
    }
}
